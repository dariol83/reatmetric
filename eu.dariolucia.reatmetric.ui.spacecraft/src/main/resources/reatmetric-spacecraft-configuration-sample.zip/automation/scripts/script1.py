info("Test message from script1.py with values " + str(arg1) + ", " + str(arg2))
_result = 123