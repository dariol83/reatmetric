// arg1 and arg2 are from the activity arguments
info("Test message from script1.groovy with values " + arg1 + ", " + arg2)
123